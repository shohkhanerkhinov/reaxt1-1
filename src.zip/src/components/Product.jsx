import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addProduct, removeProduct, updateProduct } from '../redux/productsSlice ';

const App = () => {
  const [productName, setProductName] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productQuantity, setProductQuantity] = useState('');
  const [editProductId, setEditProductId] = useState(null);

  const products = useSelector(state => state.products.products);
  const dispatch = useDispatch();

  const handleAddProduct = () => {
    const newProduct = {
      id: Date.now(),
      name: productName,
      price: parseFloat(productPrice),
      quantity: parseInt(productQuantity),
    };
    dispatch(addProduct(newProduct));
    setProductName('');
    setProductPrice('');
    setProductQuantity('');
  };

  const handleRemoveProduct = (id) => {
    dispatch(removeProduct(id));
  };

  const handleUpdateProduct = () => {
    const updatedProduct = {
      id: editProductId,
      name: productName,
      price: parseFloat(productPrice),
      quantity: parseInt(productQuantity),
    };
    dispatch(updateProduct(updatedProduct));
    setEditProductId(null);
    setProductName('');
    setProductPrice('');
    setProductQuantity('');
  };

  const handleEditProduct = (product) => {
    setEditProductId(product.id);
    setProductName(product.name);
    setProductPrice(product.price);
    setProductQuantity(product.quantity);
  };

  return (
    <div>
      <h1>Mahsulotlar Ro'yxati</h1>
      <div>
        <input
          type="text"
          placeholder="Mahsulot nomi"
          value={productName}
          onChange={(e) => setProductName(e.target.value)}
        />
        <input
          type="number"
          placeholder="Narxi"
          value={productPrice}
          onChange={(e) => setProductPrice(e.target.value)}
        />
        <input
          type="number"
          placeholder="Miqdori"
          value={productQuantity}
          onChange={(e) => setProductQuantity(e.target.value)}
        />
        {editProductId ? (
          <button onClick={handleUpdateProduct}>Yangilash</button>
        ) : (
          <button onClick={handleAddProduct}>Qo'shish</button>
        )}
      </div>
      <ul>
        {products.map(product => (
          <li key={product.id}>
            {product.name} - {product.price} so'm - {product.quantity} ta
            <button onClick={() => handleEditProduct(product)}>Tahrirlash</button>
            <button onClick={() => handleRemoveProduct(product.id)}>O'chirish</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;